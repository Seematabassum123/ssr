package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.ResearchPublications;
import com.example.demo.model.StudentDetails;

public interface ResearchPublicationsrepository extends JpaRepository<ResearchPublications,Long> {
	
	List<ResearchPublications> findBydepartmentContaining(String department);

}
