package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.StudentDetails;

import java.util.*;

@Repository
public interface StudentDetailsrepository extends JpaRepository<StudentDetails, Long> 
{
	List<StudentDetails> findByemailContaining(String email);
}
