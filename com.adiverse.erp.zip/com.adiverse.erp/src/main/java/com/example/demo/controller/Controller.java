package com.example.demo.controller;


import java.util.*;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.StudentDetails;
import com.example.demo.repository.DocumentSubmissionrepository;
import com.example.demo.repository.LaptopAvailabilityrepository;
import com.example.demo.repository.StudentDetailsrepository;


@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1")
public class Controller	
{
	
	@Autowired
	StudentDetailsrepository studentdetailsRepository;
	
	@Autowired
	DocumentSubmissionrepository documentsubmissionRepository;
	
	 @Autowired
	 LaptopAvailabilityrepository laptopavailabilityRepository;
	 
	

	 @PostMapping("/studentinfo")
	  public ResponseEntity<StudentDetails> createTutorial(@RequestBody StudentDetails studentDetails) {
	    try {
	    	StudentDetails student = studentdetailsRepository
	          .save(studentDetails);
	      return new ResponseEntity<>(student, HttpStatus.CREATED);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }


	  @GetMapping("/academyssr")
	  public ResponseEntity<List<StudentDetails>> getAllTutorials(@RequestParam(required = false) String email) {
	    try {
	      List<StudentDetails> tutorials = new ArrayList<StudentDetails>();
	      if (email == null)
	    	  studentdetailsRepository.findAll().forEach(tutorials::add);
	      else
	    	  studentdetailsRepository.findByemailContaining(email).forEach(tutorials::add);
	      if (tutorials.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }
	      return new ResponseEntity<>(tutorials, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	  @GetMapping("/tutorials/{id}")
	  public ResponseEntity<StudentDetails> getTutorialById(@PathVariable("id") long id) {
	    Optional<StudentDetails> tutorialData = studentdetailsRepository.findById(id);
	    if (tutorialData.isPresent()) {
	      return new ResponseEntity<>(tutorialData.get(), HttpStatus.OK);
	    } else {
	      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	  }
}