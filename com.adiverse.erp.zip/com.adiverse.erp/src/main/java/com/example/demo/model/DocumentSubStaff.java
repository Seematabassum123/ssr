package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="documentstaff")
public class DocumentSubStaff {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long document_id;
	@Column(name = "email")
	private String email;
	@Column(name = "staff")
	private String staff;
	@Column(name = "staffid")
	private String staffid;
	@Column(name = "nameofthestaff")
	private String nameofthestaff;
	@Column(name = "department")
	private int department;
//	@Column(name = "uploadeachdocumentseparately")
//	private String uploadeachdocumentseparately;
	@Column(name = "remarks")
	private String remarks;
	public long getDocument_id() {
		return document_id;
	}
	public void setDocument_id(long document_id) {
		this.document_id = document_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getStaff() {
		return staff;
	}
	public void setStaff(String staff) {
		this.staff = staff;
	}
	public String getStaffid() {
		return staffid;
	}
	public void setStaffid(String staffid) {
		this.staffid = staffid;
	}
	public String getNameofthestaff() {
		return nameofthestaff;
	}
	public void setNameofthestaff(String nameofthestaff) {
		this.nameofthestaff = nameofthestaff;
	}
	public int getDepartment() {
		return department;
	}
	public void setDepartment(int department) {
		this.department = department;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	

}
