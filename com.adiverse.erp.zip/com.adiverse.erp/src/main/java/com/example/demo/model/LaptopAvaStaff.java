package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="laptopstaff")

public class LaptopAvaStaff {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long laptop_id;
	@Column(name = "email")
	private String email;
	@Column(name = "employeeid")
	private String employeeid;
	@Column(name = "nameofthestaff")
	private String nameofthestaff;
	@Column(name = "department")
	private String department;
	@Column(name = "whetherlaptopisavailable")
	private String whetherlaptopisavailable;
	@Column(name = "model")
	private String model;
	@Column(name = "ramsize")
	private int ramsize;
	@Column(name = "hddcapacity")
	private String  hddcapacity;
	@Column(name = "typeofinternetfacilityavailable")
	private String typeofinternetfacilityavailable;
	@Column(name = "remarks")
	private String remarks;
	public long getLaptop_id() {
		return laptop_id;
	}
	public void setLaptop_id(long laptop_id) {
		this.laptop_id = laptop_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}
	public String getNameofthestaff() {
		return nameofthestaff;
	}
	public void setNameofthestaff(String nameofthestaff) {
		this.nameofthestaff = nameofthestaff;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getWhetherlaptopisavailable() {
		return whetherlaptopisavailable;
	}
	public void setWhetherlaptopisavailable(String whetherlaptopisavailable) {
		this.whetherlaptopisavailable = whetherlaptopisavailable;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getRamsize() {
		return ramsize;
	}
	public void setRamsize(int ramsize) {
		this.ramsize = ramsize;
	}
	public String getHddcapacity() {
		return hddcapacity;
	}
	public void setHddcapacity(String hddcapacity) {
		this.hddcapacity = hddcapacity;
	}
	public String getTypeofinternetfacilityavailable() {
		return typeofinternetfacilityavailable;
	}
	public void setTypeofinternetfacilityavailable(String typeofinternetfacilityavailable) {
		this.typeofinternetfacilityavailable = typeofinternetfacilityavailable;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
	
	

}
