package com.example.demo.model;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="studentform1")
public class StudentDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long student_id;
	@Column(name = "email")
	private String email;
	@Column(name = "studentrollno")
	private String studentrollno;
	@Column(name = "nameofthestudent")
	private String nameofthestudent;
	@Column(name = "contactnumber")
	private int contactnumber;
	@Column(name = "programme")
	private String programme;
	@Column(name = "department")
	private String department;
	@Column(name = "year")
	private int year;
	@Column(name = "section")
	private String  section;
	@Column(name = "Documents")
	private String documents;
	@Column(name = "address")
	private String address;
//	@Column(name = "handwrittenrequestletter")
//	private String handwrittenrequestletter;
	@Column(name = "remarks")
	private String remarks;
	
	@OneToMany(targetEntity=LaptopAvailability.class,cascade=CascadeType.ALL)
	@JoinColumn(name="student_forignkey",referencedColumnName="student_id")
	private List<LaptopAvailability> laptopAvailability;
	
	
	
	
	@OneToMany(targetEntity=DocumentSubmission.class,cascade=CascadeType.ALL)
	  @JoinColumn(name="student_forignkey",referencedColumnName="student_id")
	  private List<DocumentSubmission> documentsubmission;
	 


	public List<DocumentSubmission> getDocumentsubmission() {
		return documentsubmission;
	}


	public void setDocumentsubmission(List<DocumentSubmission> documentsubmission) {
		this.documentsubmission = documentsubmission;
	}


	public long getStudent_id() {
		return student_id;
	}


	public void setStudent_id(long student_id) {
		this.student_id = student_id;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getStudentrollno() {
		return studentrollno;
	}


	public void setStudentrollno(String studentrollno) {
		this.studentrollno = studentrollno;
	}


	public String getNameofthestudent() {
		return nameofthestudent;
	}


	public void setNameofthestudent(String nameofthestudent) {
		this.nameofthestudent = nameofthestudent;
	}


	public int getContactnumber() {
		return contactnumber;
	}


	public void setContactnumber(int contactnumber) {
		this.contactnumber = contactnumber;
	}


	public String getProgramme() {
		return programme;
	}


	public void setProgramme(String programme) {
		this.programme = programme;
	}


	public String getDepartment() {
		return department;
	}


	public void setDepartment(String department) {
		this.department = department;
	}


	public int getYear() {
		return year;
	}


	public void setYear(int year) {
		this.year = year;
	}


	public String getSection() {
		return section;
	}


	public void setSection(String section) {
		this.section = section;
	}


	public String getDocuments() {
		return documents;
	}


	public void setDocuments(String documents) {
		this.documents = documents;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


//	public String getHandwrittenrequestletter() {
//		return handwrittenrequestletter;
//	}
//
//
//	public void setHandwrittenrequestletter(String handwrittenrequestletter) {
//		this.handwrittenrequestletter = handwrittenrequestletter;
//	}


	public String getRemarks() {
		return remarks;
	}


	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}


	public List<LaptopAvailability> getLaptopAvailability() {
		return laptopAvailability;
	}


	public void setLaptopAvailability(List<LaptopAvailability> laptopAvailability) {
		this.laptopAvailability = laptopAvailability;
	}


	


	/*
	 * public DocumentSubmission getDocumentsubmission() { return
	 * documentsubmission; }
	 * 
	 * 
	 * public void setDocumentsubmission(DocumentSubmission documentsubmission) {
	 * this.documentsubmission = documentsubmission; }
	 */
	
	
	
}


