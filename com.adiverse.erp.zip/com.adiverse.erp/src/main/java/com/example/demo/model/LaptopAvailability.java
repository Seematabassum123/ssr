package com.example.demo.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="laptop")

public class LaptopAvailability {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long laptop_id;
	@Column(name = "email")
	private String email;
	@Column(name = "studentrollno")
	private String studentrollno;
	@Column(name = "nameofthestudent")
	private String nameofthestudent;
	@Column(name = "department")
	private String department;
	@Column(name = "whetherlaptopisavailable")
	private String whetherlaptopisavailable;
	@Column(name = "model")
	private String model;
	@Column(name = "ramsize")
	private int ramsize;
	@Column(name = "hddcapacity")
	private String  hddcapacity;
	@Column(name = "typeofinternetfacilityavailable")
	private String typeofinternetfacilityavailable;
	@Column(name = "remarks")
	private String remarks;
	
	public LaptopAvailability(long laptop_id, String email, String studentrollno, String nameofthestudent,
			String department, String whetherlaptopisavailable, String model, int ramsize, String hddcapacity,
			String typeofinternetfacilityavailable, String remarks) {
		this.laptop_id = laptop_id;
		this.email = email;
		this.studentrollno = studentrollno;
		this.nameofthestudent = nameofthestudent;
		this.department = department;
		this.whetherlaptopisavailable = whetherlaptopisavailable;
		this.model = model;
		this.ramsize = ramsize;
		this.hddcapacity = hddcapacity;
		this.typeofinternetfacilityavailable = typeofinternetfacilityavailable;
		this.remarks = remarks;
	}

	public long getLaptop_id() {
		return laptop_id;
	}

	public void setLaptop_id(long laptop_id) {
		this.laptop_id = laptop_id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStudentrollno() {
		return studentrollno;
	}

	public void setStudentrollno(String studentrollno) {
		this.studentrollno = studentrollno;
	}

	public String getNameofthestudent() {
		return nameofthestudent;
	}

	public void setNameofthestudent(String nameofthestudent) {
		this.nameofthestudent = nameofthestudent;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public String getWhetherlaptopisavailable() {
		return whetherlaptopisavailable;
	}

	public void setWhetherlaptopisavailable(String whetherlaptopisavailable) {
		this.whetherlaptopisavailable = whetherlaptopisavailable;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getRamsize() {
		return ramsize;
	}

	public void setRamsize(int ramsize) {
		this.ramsize = ramsize;
	}

	public String getHddcapacity() {
		return hddcapacity;
	}

	public void setHddcapacity(String hddcapacity) {
		this.hddcapacity = hddcapacity;
	}

	public String getTypeofinternetfacilityavailable() {
		return typeofinternetfacilityavailable;
	}

	public void setTypeofinternetfacilityavailable(String typeofinternetfacilityavailable) {
		this.typeofinternetfacilityavailable = typeofinternetfacilityavailable;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	

}




