package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.ResearchPublications;
import com.example.demo.repository.DocumentSubStaffrepository;
import com.example.demo.repository.LaptopAvaStaffrepository;
import com.example.demo.repository.ResearchPublicationsrepository;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1")

public class ControllerStaff {
	@Autowired
	ResearchPublicationsrepository researchPublicationsRepository;
	
	@Autowired
	DocumentSubStaffrepository documentsubStaffRepository;
	
	 @Autowired
	 LaptopAvaStaffrepository laptopavaStaffRepository;
	 
	

	 @PostMapping("/researchinfo")
	  public ResponseEntity<ResearchPublications> createTutorial(@RequestBody ResearchPublications researchPublications) {
	    try {
	    	ResearchPublications research = researchPublicationsRepository
	          .save(researchPublications);
	      return new ResponseEntity<>(research, HttpStatus.CREATED);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }


	  @GetMapping("/researchinfo")
	  public ResponseEntity<List<ResearchPublications>> getAllTutorials(@RequestParam(required = false) String email) {
	    try {
	      List<ResearchPublications> tutorials = new ArrayList<ResearchPublications>();
	      String department = null;
		if (department == null)
	    	  researchPublicationsRepository.findAll().forEach(tutorials::add);
	      else
	    	  researchPublicationsRepository.findBydepartmentContaining(department).forEach(tutorials::add);
	      if (tutorials.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }
	      return new ResponseEntity<>(tutorials, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }
	  @GetMapping("/publications/{id}")
	  public ResponseEntity<ResearchPublications> getTutorialById(@PathVariable("id") long id) {
	    Optional<ResearchPublications> tutorialData = researchPublicationsRepository.findById(id);
	    if (tutorialData.isPresent()) {
	      return new ResponseEntity<>(tutorialData.get(), HttpStatus.OK);
	    } else {
	      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	    }
	  }

}
