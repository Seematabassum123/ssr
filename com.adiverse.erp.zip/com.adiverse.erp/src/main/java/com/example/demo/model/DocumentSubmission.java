package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="document")


public class DocumentSubmission {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long document_id;
	@Column(name = "email")
	private String email;
	@Column(name = "student")
	private String student;
	@Column(name = "studentrollno")
	private String studentrollno;
	@Column(name = "nameofthestudent")
	private String nameofthestudent;
	@Column(name = "department")
	private int department;
//	@Column(name = "uploadeachdocumentseparately")
//	private String uploadeachdocumentseparately;
	@Column(name = "remarks")
	private String remarks;
	public long getDocument_id() {
		return document_id;
	}
	public void setDocument_id(long document_id) {
		this.document_id = document_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getStudent() {
		return student;
	}
	public void setStudent(String student) {
		this.student = student;
	}
	public String getStudentrollno() {
		return studentrollno;
	}
	public void setStudentrollno(String studentrollno) {
		this.studentrollno = studentrollno;
	}
	public String getNameofthestudent() {
		return nameofthestudent;
	}
	public void setNameofthestudent(String nameofthestudent) {
		this.nameofthestudent = nameofthestudent;
	}
	public int getDepartment() {
		return department;
	}
	public void setDepartment(int department) {
		this.department = department;
	}
//	public String getUploadeachdocumentseparately() {
//		return uploadeachdocumentseparately;
//	}
//	public void setUploadeachdocumentseparately(String uploadeachdocumentseparately) {
//		this.uploadeachdocumentseparately = uploadeachdocumentseparately;
//	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
	
}

	
	
	
	


