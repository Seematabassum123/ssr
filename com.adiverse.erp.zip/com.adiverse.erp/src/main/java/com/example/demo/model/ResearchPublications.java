package com.example.demo.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="research")
public class ResearchPublications {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long research_id;
	@Column(name = "email")
	private String email;
	@Column(name = "employeeid")
	private String employeeid;
	@Column(name = "nameofthefaculty")
	private String nameofthefaculty;
	@Column(name = "department")
	private String department;
	@Column(name = "scopusid")
	private String scopusid;
	@Column(name = "scopusindexofcmrgiauthours")
	private String model;
	@Column(name = "ranking")
	private String ranking;
	@Column(name = "vidwanid")
	private String  vidwanid;
	@Column(name = "titleofthepublication")
	private String typeofthepublication;
	@Column(name = "nameofthejournal")
	private String nameofjournal;
	@Column(name = "issn")
	private String  issn;
	@Column(name = "volumeno")
	private String volumeno;
	@Column(name = "issueno")
	private String issueno;
	@Column(name = "monthofpublication")
	private String monthofpublication;
	@Column(name = "yearofpublication")
	private String  yearofpublication;
	@Column(name = "digitalobjectidentifier")
	private String digitalidentobject;
	//@Column(name = "uploadfullpaper")
	//private String uploadfullpaper;
	//@Column(name = "upoloadscannedoriginalfeereceipt")
	//private String  upoloadscannedoriginalfeereceipt;
	@Column(name = "remarks")
	private String remarks;
	
	
	@OneToMany(targetEntity=LaptopAvaStaff.class,cascade=CascadeType.ALL)
	@JoinColumn(name="research_forignkey",referencedColumnName="research_id")
	private List<LaptopAvaStaff> laptopavastaff;
	
	
	
	
	@OneToMany(targetEntity=DocumentSubmission.class,cascade=CascadeType.ALL)
	  @JoinColumn(name="research_forignkey",referencedColumnName="research_id")
	  private List<DocumentSubStaff> documentsubstaff;
	
	
	
	public long getRsearch_id() {
		return research_id;
	}
	public void setRsearch_id(long rsearch_id) {
		this.research_id = rsearch_id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEmployeeid() {
		return employeeid;
	}
	public void setEmployeeid(String employeeid) {
		this.employeeid = employeeid;
	}
	public String getNameofthefaculty() {
		return nameofthefaculty;
	}
	public void setNameofthefaculty(String nameofthefaculty) {
		this.nameofthefaculty = nameofthefaculty;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getScopusid() {
		return scopusid;
	}
	public void setScopusid(String scopusid) {
		this.scopusid = scopusid;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	public long getResearch_id() {
		return research_id;
	}
	public void setResearch_id(long research_id) {
		this.research_id = research_id;
	}
	public String getRanking() {
		return ranking;
	}
	public void setRanking(String ranking) {
		this.ranking = ranking;
	}
	public String getVidwanid() {
		return vidwanid;
	}
	public void setVidwanid(String vidwanid) {
		this.vidwanid = vidwanid;
	}
	public String getTypeofthepublication() {
		return typeofthepublication;
	}
	public void setTypeofthepublication(String typeofthepublication) {
		this.typeofthepublication = typeofthepublication;
	}
	public String getNameofjournal() {
		return nameofjournal;
	}
	public void setNameofjournal(String nameofjournal) {
		this.nameofjournal = nameofjournal;
	}
	public String getIssn() {
		return issn;
	}
	public void setIssn(String issn) {
		this.issn = issn;
	}
	public String getVolumeno() {
		return volumeno;
	}
	public void setVolumeno(String volumeno) {
		this.volumeno = volumeno;
	}
	public String getIssueno() {
		return issueno;
	}
	public void setIssueno(String issueno) {
		this.issueno = issueno;
	}
	public String getMonthofpublication() {
		return monthofpublication;
	}
	public void setMonthofpublication(String monthofpublication) {
		this.monthofpublication = monthofpublication;
	}
	public String getYearofpublication() {
		return yearofpublication;
	}
	public void setYearofpublication(String yearofpublication) {
		this.yearofpublication = yearofpublication;
	}
	public String getDigitalidentobject() {
		return digitalidentobject;
	}
	public void setDigitalidentobject(String digitalidentobject) {
		this.digitalidentobject = digitalidentobject;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public List<LaptopAvaStaff> getLaptopavastaff() {
		return laptopavastaff;
	}
	public void setLaptopavastaff(List<LaptopAvaStaff> laptopavastaff) {
		this.laptopavastaff = laptopavastaff;
	}
	public List<DocumentSubStaff> getDocumentsubstaff() {
		return documentsubstaff;
	}
	public void setDocumentsubstaff(List<DocumentSubStaff> documentsubstaff) {
		this.documentsubstaff = documentsubstaff;
	}
	
	
	
	
}
